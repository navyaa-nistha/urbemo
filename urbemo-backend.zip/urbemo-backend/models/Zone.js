const mongoose = require('mongoose');

const ZoneSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true
  },
  location: {
    // GeoJSON format is best for mapping/coordinates
    type: { type: String, default: 'Point' },
    coordinates: { type: [Number], required: true } // [Longitude, Latitude]
  },
  currentEmotion: {
    type: String, // e.g., "Happy", "Stressed"
    default: "Neutral"
  },
  stressLevel: {
    type: Number,
    default: 0
  },
  lastUpdated: {
    type: Date,
    default: Date.now
  }
});

module.exports = mongoose.model('Zone', ZoneSchema);