const axios = require('axios');

// --- CONFIGURATION ---
const TOMTOM_KEY = 'MC6rQ3PEdR30OhO76KgTLdytOJSBfGOw'; // <--- PASTE KEY
const OWM_KEY = 'c1465238b5cbfa76a9bd4e833e059a4c';       // <--- PASTE KEY
// REPLACE THE OLD LINE WITH THIS:
const API_URL = 'https://urbemo-backend.onrender.com/api/zones';

// The Zones (Varanasi Coordinates)
const ZONES = [
    { name: "Cantonment", lat: 25.3250, lon: 82.9850 },
    { name: "Godowlia", lat: 25.3100, lon: 82.9700 }, // Usually busy
    { name: "Lanka", lat: 25.2800, lon: 82.9900 },
    { name: "Sarnath", lat: 25.3762, lon: 83.0227 },  // Usually quiet
];

// --- REAL DATA FETCHERS ---

// 1. Get Traffic Stress from TomTom
// We compare "Current Speed" vs "Free Flow Speed"
async function getTrafficData(lat, lon) {
    try {
        const url = `https://api.tomtom.com/traffic/services/4/flowSegmentData/absolute/10/json?key=${TOMTOM_KEY}&point=${lat},${lon}`;
        const res = await axios.get(url);
        const data = res.data.flowSegmentData;

        const currentSpeed = data.currentSpeed;
        const freeFlowSpeed = data.freeFlowSpeed;
        
        // Calculate Congestion (0 to 10 scale)
        // If current speed is 10% of free flow, congestion is HIGH.
        let congestion = 10 - ((currentSpeed / freeFlowSpeed) * 10);
        return Math.max(0, Math.min(Math.round(congestion), 10)); // Clamp between 0-10
    } catch (error) {
        console.log("⚠️ Using fallback traffic data (API Limit/Error)");
        return Math.floor(Math.random() * 5); // Fallback
    }
}

// 2. Get Weather Modifiers from OpenWeather
async function getWeatherData(lat, lon) {
    try {
        const url = `https://api.openweathermap.org/data/2.5/weather?lat=${lat}&lon=${lon}&appid=${OWM_KEY}&units=metric`;
        const res = await axios.get(url);
        
        // Return temp and a "crowd modifier" (People stay inside if it rains)
        const isRaining = res.data.weather[0].main === 'Rain';
        return {
            temp: res.data.main.temp,
            crowdModifier: isRaining ? 0.4 : 1.0 // 40% crowd if raining
        };
    } catch (error) {
        return { temp: 30, crowdModifier: 1.0 }; // Fallback
    }
}

// --- MAIN ENGINE ---

const collectRealData = async () => {
    console.log("📡 Fetching LIVE data from TomTom & OpenWeather...");

    for (const zone of ZONES) {
        
        // A. Fetch from Real APIs
        const trafficScore = await getTrafficData(zone.lat, zone.lon); // 0-10
        const weather = await getWeatherData(zone.lat, zone.lon);

        // B. Infer "Noise" and "Crowd" based on Traffic (Since we lack mics)
        // More Traffic usually = More Noise
        // Hotter weather usually = Less Crowd in afternoon
        
        const inferredNoise = (trafficScore * 8) + 40; // Base 40dB + traffic noise
        const inferredCrowd = (trafficScore * 10) * weather.crowdModifier;

        const payload = {
            name: zone.name,
            location: { coordinates: [zone.lon, zone.lat] },
            sensorData: {
                noiseLevel: inferredNoise,      // Calculated from real traffic
                trafficDensity: trafficScore,   // REAL from TomTom
                crowdLevel: inferredCrowd       // Calculated from real traffic + weather
            }
        };

        // C. Send to Backend
        try {
            const res = await axios.post(API_URL, payload);
            console.log(`✅ ${zone.name}: Traffic ${trafficScore}/10 | Noise ${inferredNoise}dB -> ${res.data.currentEmotion}`);
        } catch (err) {
            console.error(`❌ Error updating ${zone.name}`);
        }
    }

    console.log("--- Batch Complete. Waiting 60 seconds (to save API quota) ---");
};

// Run loop
collectRealData();
setInterval(collectRealData, 60000); // Check every 60 seconds