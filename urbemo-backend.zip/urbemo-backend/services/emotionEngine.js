/**
 * Urbemo Emotion Engine
 * Analyzes raw city data to determine zone sentiment.
 */

// Simple algorithm to calculate stress based on inputs
// Inputs could be: noiseLevel (dB), trafficDensity (0-10), crowdLevel (0-100)
const calculateStressScore = (data) => {
    let score = 0;

    // 1. Normalize Noise (Assume 100dB is max stress)
    if (data.noiseLevel) {
        score += (data.noiseLevel / 100) * 40; // Noise accounts for 40% of stress
    }

    // 2. Normalize Traffic (Assume 10 is gridlock)
    if (data.trafficDensity) {
        score += (data.trafficDensity / 10) * 30; // Traffic accounts for 30%
    }

    // 3. Normalize Crowd (Assume 100 is max capacity)
    if (data.crowdLevel) {
        score += (data.crowdLevel / 100) * 30; // Crowds account for 30%
    }

    // Cap score at 100
    return Math.min(Math.round(score), 100);
};

// Map the numeric score to a human-readable emotion
const determineLabel = (score) => {
    if (score >= 80) return "Chaotic"; // Red on heat map
    if (score >= 60) return "Tense";   // Orange
    if (score >= 40) return "Vibrant"; // Yellow
    if (score >= 20) return "Active";  // Green
    return "Calm";                     // Blue
};

// Generate AI suggestion based on the result
const generateSuggestion = (label) => {
    const suggestions = {
        "Chaotic": "Alert: High congestion. Suggest rerouting traffic.",
        "Tense": "Warning: Noise levels rising. Monitor crowd density.",
        "Vibrant": "Optimal: High activity but stable flow.",
        "Active": "Normal: Standard city activity.",
        "Calm": "Low Activity: Suitable for maintenance or leisure events."
    };
    return suggestions[label] || "No action needed.";
};

// Main function to export
exports.analyze = (sensorData) => {
    const stressScore = calculateStressScore(sensorData);
    const emotionLabel = determineLabel(stressScore);
    const suggestion = generateSuggestion(emotionLabel);

    return {
        score: stressScore,
        emotion: emotionLabel,
        suggestion: suggestion,
        processedAt: new Date()
    };
};