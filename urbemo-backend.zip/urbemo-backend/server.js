const express = require('express');
const cors = require('cors');
const app = express();

// ✅ 1. Allow connections from anywhere
app.use(cors({ origin: '*' })); 
app.use(express.json());

const PORT = 5000; 

// ✅ 2. Global State for Simulator
let currentScenario = 'normal';

// ✅ 3. MASTER LOCATION DATABASE (Matches your Dropdown exactly)
const ALL_ZONES = [
    // --- VARANASI ---
    { id: 'A', name: 'Lanka (VNS)', lat: 25.3176, lng: 82.9739 },
    { id: 'B', name: 'Godowlia (VNS)', lat: 25.3240, lng: 82.9850 },
    { id: 'C', name: 'Assi Ghat (VNS)', lat: 25.2957, lng: 83.0062 },
    { id: 'VNS_BHU', name: 'BHU Campus', lat: 25.2677, lng: 82.9913 },
    { id: 'VNS_CANT', name: 'Varanasi Cantonment', lat: 25.3433, lng: 82.9738 },
    
    // --- DELHI ---
    { id: 'DL_CP', name: 'Connaught Place', lat: 28.6304, lng: 77.2177 },
    { id: 'DL_IG', name: 'India Gate', lat: 28.6129, lng: 77.2295 },
    { id: 'DL_HK', name: 'Hauz Khas', lat: 28.5494, lng: 77.2001 },
    { id: 'DL_DW', name: 'Dwarka', lat: 28.5882, lng: 77.0494 },
    { id: 'DL_ROH', name: 'Rohini', lat: 28.7041, lng: 77.1025 },

    // --- RAJASTHAN ---
    { id: 'RJ_JP', name: 'Jaipur', lat: 26.9124, lng: 75.7873 },
    { id: 'RJ_UD', name: 'Udaipur', lat: 24.5854, lng: 73.7125 },
    { id: 'RJ_JD', name: 'Jodhpur', lat: 26.2389, lng: 73.0243 },
    { id: 'RJ_JS', name: 'Jaisalmer', lat: 26.9157, lng: 70.9083 },
    { id: 'RJ_KT', name: 'Kota', lat: 25.2138, lng: 75.8648 },
    { id: 'RJ_AJ', name: 'Ajmer', lat: 26.4499, lng: 74.6399 }
];

// Helper: Generate realistic random data
const getSafeData = () => ({
    traffic: 30 + Math.floor(Math.random() * 40),
    aqi: 120 + Math.floor(Math.random() * 80), // Raw AQI (e.g. 156)
    noise: 45 + Math.floor(Math.random() * 35),
    crowd: 20 + Math.floor(Math.random() * 50)
});

// --- ROUTES ---

// 1. STATS (For Dashboard/Simulator)
app.get('/api/stats', (req, res) => {
    let stats = { traffic: 45, noise: 50, crowd: 40, aqi: 150, score: 45 };

    if (currentScenario === 'festival') {
        stats = { traffic: 85, noise: 92, crowd: 95, aqi: 190, score: 82 };
    } else if (currentScenario === 'accident') {
        stats = { traffic: 98, noise: 75, crowd: 60, aqi: 165, score: 88 };
    } else if (currentScenario === 'rain') {
        stats = { traffic: 65, noise: 30, crowd: 15, aqi: 60, score: 55 };
    }
    res.json({ scenario: currentScenario, ...stats });
});

// 2. SET SCENARIO
app.post('/api/set-scenario', (req, res) => {
    const { type } = req.body;
    currentScenario = type || 'normal';
    console.log(`🔄 Scenario switched to: ${currentScenario}`);
    res.json({ success: true, scenario: currentScenario });
});

// 3. MAP ZONES (Calculates Stress Live)
app.get('/api/zones', (req, res) => {
    const data = ALL_ZONES.map(z => {
        let { traffic, aqi, noise, crowd } = getSafeData();
        
        // Apply Scenario Effects
        if (currentScenario === 'rain') { traffic += 20; aqi = 50; crowd = 10; }
        if (currentScenario === 'accident') { traffic = 95; noise += 10; }
        if (currentScenario === 'festival') { traffic += 30; crowd = 90; noise = 85; }

        // Calc Stress Score (0-100)
        const stress = Math.min(100, Math.round((traffic + (aqi/4) + crowd) / 3));
        
        let emotion = 'calm', color = '#22C55E';
        if (stress >= 70) { emotion = 'anger'; color = '#EF4444'; }
        else if (stress >= 40) { emotion = 'stress'; color = '#EAB308'; }

        return { ...z, traffic, aqi, score: stress, emotion, color };
    });
    res.json(data);
});

// 4. ZONE DETAIL (Single Zone Data)
app.get('/api/zone/:id', (req, res) => {
    const zone = ALL_ZONES.find(z => z.id === req.params.id);
    if (!zone) return res.status(404).json({ error: "Zone not found" });

    let factors = getSafeData();
    // Apply Scenario
    if (currentScenario === 'festival') { factors.crowd = 95; factors.noise = 90; }
    
    res.json({
        ...zone,
        score: Math.round((factors.traffic + factors.crowd + (factors.aqi/4))/3),
        factors
    });
});

app.listen(PORT, () => {
    console.log(`✅ URBEMO Backend running on http://localhost:${PORT}`);
});