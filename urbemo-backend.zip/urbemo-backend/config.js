const CONFIG = {
    // If you host this online later, change this URL
    API_BASE_URL: 'http://localhost:3000/api' 
};