const express = require('express');
const router = express.Router();

// --- IN-MEMORY DATABASE ---
let ZONES_DB = [];

// GET: Show all zones
router.get('/', (req, res) => {
    res.json(ZONES_DB);
});

// POST: Receive data from Collector
router.post('/', (req, res) => {
    try {
        const { name, location, sensorData } = req.body;

        // Simple stress calculation
        let stressScore = 0;
        if (sensorData) {
             // Calculate score based on noise/traffic
             stressScore = (sensorData.noiseLevel || 0) * 0.5 + (sensorData.trafficDensity || 0) * 5;
             if (stressScore > 100) stressScore = 100;
        }

        // Determine Emotion
        let emotion = "Calm";
        if (stressScore > 80) emotion = "Chaotic";
        else if (stressScore > 50) emotion = "Tense";
        else if (stressScore > 20) emotion = "Active";

        // Create/Update Zone
        const zoneData = {
            id: name.replace(/\s+/g, '-').toLowerCase(),
            name,
            location, // Keeps the format { coordinates: [lon, lat] }
            currentEmotion: emotion,
            stressLevel: Math.round(stressScore),
            lastUpdated: new Date()
        };

        // Update if exists, Push if new
        const existingIndex = ZONES_DB.findIndex(z => z.name === name);
        if (existingIndex >= 0) {
            ZONES_DB[existingIndex] = zoneData;
        } else {
            ZONES_DB.push(zoneData);
        }

        console.log(`Updated zone: ${name}`);
        res.json(zoneData);

    } catch (err) {
        console.error(err);
        res.status(400).json({ message: "Invalid Data" });
    }
});

module.exports = router;