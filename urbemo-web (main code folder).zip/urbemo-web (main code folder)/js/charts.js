// ========================================
// URBEMO - Chart Creation Functions
// ========================================

// Create Pie Chart for Emotion Breakdown
function createBreakdownChart(canvasId, data) {
    const ctx = document.getElementById(canvasId);
    
    if (!ctx) {
        console.error('Canvas not found:', canvasId);
        return null;
    }
    
    return new Chart(ctx.getContext('2d'), {
        type: 'pie',
        data: {
            labels: ['Traffic', 'Noise', 'Crowd', 'Pollution', 'Complaints'],
            datasets: [{
                data: data || [35, 25, 20, 15, 5],
                backgroundColor: [
                    '#EF4444',  // Traffic - Red
                    '#F97316',  // Noise - Orange
                    '#EAB308',  // Crowd - Yellow
                    '#3B82F6',  // Pollution - Blue
                    '#94A3B8'   // Complaints - Gray
                ],
                borderWidth: 2,
                borderColor: '#FFFFFF'
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: true,
            plugins: {
                legend: {
                    position: 'bottom',
                    labels: {
                        padding: 15,
                        font: {
                            size: 12
                        }
                    }
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return context.label + ': ' + context.parsed + '%';
                        }
                    }
                }
            }
        }
    });
}

// Create Timeline Chart
function createTimelineChart(canvasId, timeData) {
    const ctx = document.getElementById(canvasId);
    
    if (!ctx) {
        console.error('Canvas not found:', canvasId);
        return null;
    }
    
    return new Chart(ctx.getContext('2d'), {
        type: 'line',
        data: {
            labels: timeData.labels || ['Morning', 'Afternoon', 'Evening', 'Night'],
            datasets: [{
                label: 'Emotion Score',
                data: timeData.data || [40, 55, 82, 60],
                borderColor: '#EF4444',
                backgroundColor: 'rgba(239, 68, 68, 0.1)',
                tension: 0.4,
                fill: true,
                pointRadius: 5,
                pointHoverRadius: 7,
                pointBackgroundColor: '#EF4444',
                pointBorderColor: '#FFFFFF',
                pointBorderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: true,
            plugins: {
                legend: {
                    display: true,
                    position: 'top'
                },
                tooltip: {
                    mode: 'index',
                    intersect: false
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    max: 100,
                    ticks: {
                        callback: function(value) {
                            return value;
                        }
                    },
                    grid: {
                        color: 'rgba(0, 0, 0, 0.05)'
                    }
                },
                x: {
                    grid: {
                        display: false
                    }
                }
            }
        }
    });
}

// Create Trend Chart for Dashboard
function createTrendChart(canvasId, trendData) {
    const ctx = document.getElementById(canvasId);
    
    if (!ctx) {
        console.error('Canvas not found:', canvasId);
        return null;
    }
    
    return new Chart(ctx.getContext('2d'), {
        type: 'line',
        data: {
            labels: trendData.labels || ['9 AM', '12 PM', '3 PM', '6 PM', '9 PM'],
            datasets: [{
                label: 'Stress Level',
                data: trendData.data || [40, 55, 65, 82, 60],
                borderColor: '#EF4444',
                backgroundColor: 'rgba(239, 68, 68, 0.1)',
                tension: 0.4,
                fill: true,
                pointRadius: 6,
                pointHoverRadius: 8,
                pointBackgroundColor: '#EF4444',
                pointBorderColor: '#FFFFFF',
                pointBorderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: true,
            plugins: {
                legend: {
                    display: false
                },
                tooltip: {
                    backgroundColor: '#1E3A8A',
                    padding: 12,
                    titleFont: {
                        size: 14
                    },
                    bodyFont: {
                        size: 13
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    max: 100,
                    ticks: {
                        font: {
                            size: 12
                        }
                    },
                    grid: {
                        color: 'rgba(0, 0, 0, 0.05)'
                    }
                },
                x: {
                    ticks: {
                        font: {
                            size: 12
                        }
                    },
                    grid: {
                        display: false
                    }
                }
            }
        }
    });
}

console.log('Charts module loaded');
