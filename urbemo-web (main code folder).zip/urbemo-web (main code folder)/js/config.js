// ========================================
// URBEMO - Configuration File
// ========================================

// Firebase Configuration
// Replace with your actual Firebase config
const firebaseConfig = {
    apiKey: "YOUR_API_KEY",
    authDomain: "urbemo-project.firebaseapp.com",
    projectId: "urbemo-project",
    storageBucket: "urbemo-project.appspot.com",
    messagingSenderId: "YOUR_SENDER_ID",
    appId: "YOUR_APP_ID"
};

// Initialize Firebase (if Firebase is loaded)
if (typeof firebase !== 'undefined') {
    firebase.initializeApp(firebaseConfig);
}

// Backend API URL
// Change this to your Firebase Functions URL or backend server
const API_BASE_URL = "http://localhost:5000"; // For development
// const API_BASE_URL = "https://your-firebase-functions-url.com"; // For production

// Export configuration
window.URBEMO_CONFIG = {
    firebase: firebaseConfig,
    apiUrl: API_BASE_URL,
    cityCenter: {
        lat: 23.2156,
        lng: 72.6369,
        name: "Gandhinagar" // Change to your city
    }
};

console.log('URBEMO Config loaded');
