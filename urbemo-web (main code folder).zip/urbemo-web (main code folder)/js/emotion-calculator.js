// ========================================
// URBEMO - Emotion Scoring Algorithm
// ========================================

class EmotionCalculator {
    constructor() {
        // Weights based on research paper
        this.weights = {
            traffic: 0.30,      // 30%
            noise: 0.25,        // 25%
            complaints: 0.15,   // 15%
            aqi: 0.20,          // 20%
            crowd: 0.10         // 10%
        };
    }

    // Calculate Emotion Score (0-100)
    calculateScore(data) {
        const normalized = this.normalizeData(data);
        
        const score = 
            (normalized.traffic * this.weights.traffic) +
            (normalized.noise * this.weights.noise) +
            (normalized.complaints * this.weights.complaints) +
            (normalized.aqi * this.weights.aqi) +
            (normalized.crowd * this.weights.crowd);
        
        return Math.round(score);
    }

    // Normalize Data to 0-100 scale
    normalizeData(data) {
        return {
            traffic: this.normalize(data.traffic, 0, 100),      // 0-100% congestion
            noise: this.normalize(data.noise, 30, 120),          // 30-120 dB
            complaints: this.normalize(data.complaints, 0, 50),  // 0-50 complaints/day
            aqi: this.normalize(data.aqi, 0, 500),               // 0-500 AQI
            crowd: this.normalize(data.crowd, 0, 100)            // 0-100% density
        };
    }

    // Normalize value to 0-100 range
    normalize(value, min, max) {
        return Math.min(100, Math.max(0, ((value - min) / (max - min)) * 100));
    }

    // Get Emotion Label and Color
    getEmotionLabel(score) {
        if (score > 70) {
            return { 
                emotion: 'anger', 
                color: '#EF4444', 
                label: 'High Stress',
                emoji: '😡'
            };
        }
        
        if (score > 40) {
            return { 
                emotion: 'stress', 
                color: '#EAB308', 
                label: 'Moderate Stress',
                emoji: '😰'
            };
        }
        
        return { 
            emotion: 'calm', 
            color: '#22C55E', 
            label: 'Calm',
            emoji: '😊'
        };
    }

    // Calculate City-wide Stress Index
    calculateCityStressIndex(zones) {
        if (!zones || zones.length === 0) return 0;
        
        const totalScore = zones.reduce((sum, zone) => sum + zone.score, 0);
        return Math.round(totalScore / zones.length);
    }

    // Calculate Contributing Factors Breakdown
    calculateFactorBreakdown(data) {
        const normalized = this.normalizeData(data);
        
        return {
            traffic: Math.round(normalized.traffic * this.weights.traffic),
            noise: Math.round(normalized.noise * this.weights.noise),
            crowd: Math.round(normalized.crowd * this.weights.crowd),
            aqi: Math.round(normalized.aqi * this.weights.aqi),
            complaints: Math.round(normalized.complaints * this.weights.complaints)
        };
    }

    // Predict Emotion for Scenario
    predictScenarioEmotion(baseData, scenario) {
        let modifiedData = { ...baseData };
        
        switch(scenario) {
            case 'festival':
                modifiedData.traffic *= 1.4;
                modifiedData.noise *= 1.5;
                modifiedData.crowd *= 1.8;
                modifiedData.aqi *= 1.2;
                break;
                
            case 'accident':
                modifiedData.traffic *= 1.9;
                modifiedData.noise *= 1.3;
                modifiedData.crowd *= 1.4;
                break;
                
            case 'rain':
                modifiedData.traffic *= 1.6;
                modifiedData.noise *= 0.8;
                modifiedData.crowd *= 0.7;
                modifiedData.aqi *= 0.6;
                break;
        }
        
        return this.calculateScore(modifiedData);
    }
}

// Create global instance
const emotionCalculator = new EmotionCalculator();

// Example usage:
/*
const zoneData = {
    traffic: 75,      // 75% congestion
    noise: 85,        // 85 dB
    complaints: 12,   // 12 complaints
    aqi: 180,         // AQI of 180
    crowd: 60         // 60% density
};

const score = emotionCalculator.calculateScore(zoneData);
const emotion = emotionCalculator.getEmotionLabel(score);

console.log('Score:', score);
console.log('Emotion:', emotion);
*/

console.log('Emotion Calculator loaded');
