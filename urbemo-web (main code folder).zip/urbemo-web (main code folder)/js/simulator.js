// ========================================
// URBEMO - Simulator Logic (Final)
// ========================================

const API_URL = 'https://urbemo-backend.onrender.com/api';
let rainInterval = null;

async function simulateScenario(type) {
    console.log(`Activating Scenario: ${type}`);
    
    // 1. Reset Effects
    stopRain();
    
    // 2. Trigger Visuals
    if (type === 'rain') {
        startRain();
        setTimeout(stopRain, 8000); 
    }
    
    if (type === 'accident') {
        triggerCrash();
    }

    if (type === 'festival') {
        triggerConfetti();
    }

    // 3. Send to Server
    try {
        await fetch(`${API_URL}/set-scenario`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ type })
        });
        fetchStats(); 
    } catch (e) { console.warn("API Error:", e); }
}

// --- VISUAL HELPERS ---

function startRain() {
    if (rainInterval) return;
    rainInterval = setInterval(() => {
        const drop = document.createElement('div');
        drop.className = 'rain-drop';
        drop.style.left = Math.random() * 100 + 'vw';
        drop.style.animationDuration = (Math.random() * 0.3 + 0.5) + 's';
        document.body.appendChild(drop);
        setTimeout(() => drop.remove(), 1000);
    }, 20);
}

function stopRain() {
    if (rainInterval) clearInterval(rainInterval);
    rainInterval = null;
    document.querySelectorAll('.rain-drop').forEach(el => el.remove());
}

function triggerConfetti() {
    const colors = ['#EF4444', '#3B82F6', '#EAB308', '#22C55E', '#D4AF37', '#9333EA', '#FFC4D6'];
    
    for(let i=0; i<80; i++) {
        const c = document.createElement('div');
        c.className = 'confetti';
        
        // Random Properties
        c.style.left = Math.random() * 100 + 'vw';
        c.style.backgroundColor = colors[Math.floor(Math.random() * colors.length)];
        
        // Random Speed & Rotation
        const duration = Math.random() * 2 + 2; 
        c.style.animationDuration = duration + 's';
        
        document.body.appendChild(c);
        
        // Cleanup
        setTimeout(() => c.remove(), duration * 1000);
    }
}

function triggerCrash() {
    // Red Flash
    let flash = document.getElementById('crash-flash');
    if (!flash) {
        flash = document.createElement('div');
        flash.id = 'crash-flash';
        flash.className = 'crash-overlay';
        document.body.appendChild(flash);
    }
    flash.classList.remove('crash-active');
    void flash.offsetWidth; // Force Reflow
    flash.classList.add('crash-active');

    // Shake Container
    const container = document.querySelector('.simulator-container');
    if(container) {
        container.classList.remove('shake-hard');
        void container.offsetWidth;
        container.classList.add('shake-hard');
    }
}

// --- DATA FETCHING ---

async function fetchStats() {
    try {
        const res = await fetch(`${API_URL}/stats`);
        const data = await res.json();
        
        // Update Score
        const scoreEl = document.getElementById('simStressIndex');
        if(scoreEl) scoreEl.textContent = data.score;
        
        // Update Badge
        const badge = document.getElementById('simStressChange');
        if(badge) badge.textContent = `Scenario: ${data.scenario ? data.scenario.toUpperCase() : 'NORMAL'}`;
        
        // Update Metrics
        if(document.getElementById('simTraffic')) document.getElementById('simTraffic').textContent = data.traffic + '%';
        if(document.getElementById('simNoise')) document.getElementById('simNoise').textContent = data.noise + ' dB';
        if(document.getElementById('simCrowd')) document.getElementById('simCrowd').textContent = data.crowd + '%';
        if(document.getElementById('simAQI')) document.getElementById('simAQI').textContent = data.aqi;

    } catch (e) { console.warn("Polling...", e); }
}

document.addEventListener('DOMContentLoaded', () => {
    fetchStats();
    setInterval(fetchStats, 5000);
});