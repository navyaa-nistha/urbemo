async function initDashboard() {
    await updateDashboard();
    initTrendChart(); 
    setInterval(updateDashboard, 5000); 
    document.getElementById('loadingOverlay')?.classList.add('hidden');
}

async function updateDashboard() {
    try {
        const data = await api.getCityStats();
        const score = data.score || 0; 
        
        // 1. Update Big Number
        const scoreEl = document.getElementById('cityStressIndex');
        if (scoreEl) {
            scoreEl.textContent = score;
            scoreEl.style.color = score > 70 ? '#EF4444' : '#3f0c4f';
        }

        // 2. Update Status Text
        const statusEl = document.getElementById('stressStatus');
        if (statusEl) {
            const label = score > 70 ? 'High Stress' : (score > 40 ? 'Moderate' : 'Calm');
            statusEl.textContent = `${label} (${score}/100)`;
        }
        
        // 3. Update Bar
        const bar = document.getElementById('stressFill');
        if (bar) {
            bar.style.width = `${score}%`;
            bar.style.background = score > 70 ? '#EF4444' : (score > 40 ? '#EAB308' : '#22C55E');
        }

        // 4. Update Zone Lists
        const zones = await api.getAllZones();
        if (zones.length) updateLists(zones);

    } catch (e) { console.error(e); }
}

function updateLists(zones) {
    const render = (list, id) => {
        const el = document.getElementById(id);
        if(!el) return;
        el.innerHTML = list.length ? list.map(z => {
            // ✅ FORCE COLOR MATCH LOCALLY
            let scoreColor = '#22C55E'; // Default Green
            if (z.score >= 70) scoreColor = '#EF4444'; // Red
            else if (z.score >= 40) scoreColor = '#EAB308'; // Yellow

            return `
            <li onclick="window.location.href='zone-detail.html?id=${z.id}'" 
                 style="cursor:pointer; padding: 12px; margin-bottom: 8px; background: rgba(255,255,255,0.4); border-radius: 8px; display:flex; justify-content:space-between; align-items:center; transition: all 0.2s;">
                <span style="font-weight:600; color:#3f0c4f;">${z.name}</span> 
                <span style="font-weight:800; color:${scoreColor}; background: white; padding: 4px 12px; border-radius: 20px; box-shadow: 0 2px 5px rgba(0,0,0,0.1);">${z.score}</span>
             </li>`;
        }).join('') : '<li style="padding:10px; color:#666; font-style:italic;">No zones in this category</li>';
    };

    // Filters must match the color logic above (70 & 40)
    render(zones.filter(z => z.score >= 70), 'highStressZones');
    render(zones.filter(z => z.score >= 40 && z.score < 70), 'moderateZones');
    render(zones.filter(z => z.score < 40), 'calmZones');
}

function initTrendChart() {
    const ctx = document.getElementById('trendChart');
    if (!ctx) return;
    new Chart(ctx, {
        type: 'line',
        data: {
            labels: ['9 AM', '12 PM', '3 PM', '6 PM', '9 PM', '12 AM'],
            datasets: [{
                label: 'City Stress Level',
                data: [42, 55, 68, 85, 60, 45],
                borderColor: '#8b5cf6',
                backgroundColor: 'rgba(139, 92, 246, 0.1)',
                borderWidth: 3,
                tension: 0.4,
                fill: true
            }]
        },
        options: { 
            responsive: true, 
            maintainAspectRatio: false, 
            plugins: { legend: { display: false } },
            scales: { x: { display: false }, y: { display: false } }
        }
    });
}

document.addEventListener('DOMContentLoaded', initDashboard);