class UrbemoAPI {
    constructor() {
        this.baseUrl = 'https://urbemo-backend.onrender.com'; 
    }

    // --- 1. City Stats (Fixed to prevent "undefined") ---
    async getCityStats() {
        try {
            const res = await fetch(`${this.baseUrl}/api/stats`);
            const data = await res.json();
            
            return { 
                score: data.score || 50, 
                status: 'Live', 
                aqi: data.aqi || 120,
                traffic: data.traffic,
                noise: data.noise,
                crowd: data.crowd,
                scenario: data.scenario
            };
        } catch (e) { 
            console.error("API Error - Using Fallback:", e);
            return { score: 0, status: 'Offline', aqi: 0, scenario: 'offline' }; 
        }
    }

    async getAllZones() {
        try {
            const res = await fetch(`${this.baseUrl}/api/zones`);
            return await res.json();
        } catch (e) { return []; }
    }

    async getZoneDetail(id) {
        try {
            const res = await fetch(`${this.baseUrl}/api/zone/${id}`);
            if (!res.ok) throw new Error('Not found');
            return await res.json();
        } catch (e) { return null; }
    }
}

const api = new UrbemoAPI();