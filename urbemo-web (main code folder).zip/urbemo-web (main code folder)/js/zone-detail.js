let pieChart = null;
const zoneId = new URLSearchParams(window.location.search).get('id') || 'A';

async function initZoneDetail() {
    await fetchAndRender();
    setInterval(fetchAndRender, 5000);
}

async function fetchAndRender() {
    try {
        const zone = await api.getZoneDetail(zoneId);
        if (!zone) return;

        // Header
        document.getElementById('zoneName').textContent = zone.name;
        document.getElementById('zoneDescription').textContent = "Live Sensor Data | Real-time Analysis"; 
        
        // ✅ NEW: Update the Big Number
        document.getElementById('stressScoreValue').textContent = zone.score;

        // Emotion Badge
        const badge = document.getElementById('zoneEmotion');
        // Reset classes first
        badge.className = 'emotion-badge';
        
        // Add color class
        if (zone.score > 70) badge.classList.add('anger');
        else if (zone.score > 40) badge.classList.add('stress');
        else badge.classList.add('calm');

        document.getElementById('emotionLabel').textContent = zone.score > 70 ? 'High Stress' : zone.score > 40 ? 'Moderate' : 'Calm';

        // Cards (Traffic, Noise, etc.)
        updateCard('traffic', zone.factors.traffic, '%');
        updateCard('noise', zone.factors.noise, ' dB');
        updateCard('crowd', zone.factors.crowd, '%');
        document.getElementById('aqiValue').textContent = zone.factors.aqi; 
        document.getElementById('aqiBar').style.width = '100%'; 

        // Pie Chart
        updatePieChart(zone.factors);
        
        // AI Insight
        const top = Object.keys(zone.factors).reduce((a, b) => zone.factors[a] > zone.factors[b] ? a : b);
        document.getElementById('aiInsight').textContent = 
            `Analysis: Primary stressor is ${top.toUpperCase()}. ` +
            (zone.score > 70 ? "Action required." : "Stable.");
        
        document.getElementById('loadingOverlay')?.classList.add('hidden');
    } catch (e) { console.error(e); }
}

function updateCard(id, val, unit) {
    const elVal = document.getElementById(`${id}Value`);
    const elBar = document.getElementById(`${id}Bar`);
    
    // ✅ FIXED: Math.round(val) ensures no decimals appear
    if (elVal) elVal.textContent = Math.round(val) + unit;
    
    if (elBar) elBar.style.width = Math.min(100, val) + '%';
}

function updatePieChart(f) {
    const canvas = document.getElementById('breakdownChart');
    if (!canvas) return;
    const data = [f.traffic, f.noise, f.crowd, Math.round(f.aqi/3), 10]; 
    if (pieChart) { pieChart.data.datasets[0].data = data; pieChart.update(); } 
    else {
        pieChart = new Chart(canvas, {
            type: 'pie',
            data: {
                labels: ['Traffic', 'Noise', 'Crowd', 'AQI', 'Complaints'],
                datasets: [{ data, backgroundColor: ['#EF4444', '#F97316', '#EAB308', '#3B82F6', '#94A3B8'], borderWidth: 2 }]
            },
            options: { responsive: true, maintainAspectRatio: false }
        });
    }
}

document.addEventListener('DOMContentLoaded', initZoneDetail);