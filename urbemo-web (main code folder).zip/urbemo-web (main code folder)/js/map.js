// ========================================
// URBEMO - Connected Map (Polished)
// ========================================

let cityMap = null;

function initMap() {
    // 1. Create Map (Default: Varanasi)
    cityMap = L.map('city-map', { zoomControl: false }).setView([25.3176, 82.9739], 13);
    L.control.zoom({ position: 'topleft' }).addTo(cityMap); // Move zoom to top-left
    // ✅ CHANGED: Dark Mode Tiles (CartoDB Dark Matter)
    L.tileLayer('https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png', {
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors &copy; <a href="https://carto.com/attributions">CARTO</a>',
        subdomains: 'abcd',
        maxZoom: 20
    }).addTo(cityMap);

    // 2. Geolocation
    if ("geolocation" in navigator) {
        navigator.geolocation.getCurrentPosition(pos => {
            const { latitude, longitude } = pos.coords;
            L.marker([latitude, longitude]).addTo(cityMap).bindPopup("<b>Your Location</b>");
        });
    }

    // 3. Load Live Data
    loadZones();
    setInterval(loadZones, 5000); 
}

    // 2. Geolocation
    if ("geolocation" in navigator) {
        navigator.geolocation.getCurrentPosition(pos => {
            const { latitude, longitude } = pos.coords;
            L.marker([latitude, longitude]).addTo(cityMap).bindPopup("<b>Your Location</b>");
        });
    }

    // 3. Load Data & Refresh every 5s
    loadZones();
    setInterval(loadZones, 5000);

async function loadZones() {
    try {
        const zones = await api.getAllZones();
        
        // Remove old circles cleanly
        cityMap.eachLayer(layer => { 
            if(layer instanceof L.Circle) cityMap.removeLayer(layer); 
        });

        zones.forEach(zone => {
            // Sleek "Gold Edition" Popup
            const popupContent = `
                <div style="text-align:center; min-width: 150px; font-family: 'Segoe UI', sans-serif;">
                    <h3 style="margin:0 0 5px 0; color:#333; font-size:1.1rem; font-weight:700;">${zone.name}</h3>
                    
                    <div style="font-size: 0.8rem; color: #666; margin-bottom: 8px;">
                    </div>

                    <div style="width: 100%; height: 6px; background:${zone.color}; margin-bottom: 12px; border-radius: 10px; box-shadow: 0 2px 4px rgba(0,0,0,0.1);"></div>
                    
                    <a href="zone-detail.html?id=${zone.id}" 
                       style="display:inline-block; padding: 6px 14px; background:${zone.color}; color:white; text-decoration:none; border-radius: 20px; font-size: 0.8rem; font-weight: bold; transition: transform 0.2s;">
                       View Details &rarr;
                    </a>
                </div>
            `;

            L.circle([zone.lat, zone.lng], {
                color: zone.color,
                fillColor: zone.color,
                fillOpacity: 0.6,
                radius: 500,
                weight: 2
            }).addTo(cityMap).bindPopup(popupContent);
        });

        document.getElementById('loadingOverlay')?.classList.add('hidden');
    } catch (e) { console.error("Map Error:", e); }
}

// ✅ COORDINATES FOR DROPDOWN
const targets = {
    // Varanasi
    'A': [25.3176, 82.9739], 'B': [25.3240, 82.9850], 'C': [25.3050, 82.9650],
    'VNS_BHU': [25.2677, 82.9913], 'VNS_ASSI': [25.2957, 83.0062], 'VNS_CANT': [25.3433, 82.9738],
    // Rajasthan
    'RJ_UD': [24.5854, 73.7125], 'RJ_JP': [26.9124, 75.7873], 'RJ_JD': [26.2389, 73.0243], 
    'RJ_JS': [26.9157, 70.9083], 'RJ_KT': [25.2138, 75.8648], 'RJ_AJ': [26.4499, 74.6399],
    // Delhi
    'DL_CP': [28.6304, 77.2177], 'DL_IG': [28.6129, 77.2295], 'DL_HK': [28.5494, 77.2001], 
    'DL_DW': [28.5882, 77.0494], 'DL_ROH': [28.7041, 77.1025]
};

function goToZone() {
    const coords = targets[document.getElementById('zoneSelect').value];
    if (coords) cityMap.flyTo(coords, 14, { duration: 1.5 });
}

document.addEventListener('DOMContentLoaded', initMap);