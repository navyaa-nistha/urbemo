# URBEMO Web Application

City Emotion Intelligence System - Web Dashboard

## 🚀 Features

- **Real-time City Stress Index** - Monitor overall city emotional state
- **Interactive Emotion Map** - Visualize zone-wise emotions with heatmap
- **Zone Details** - Deep dive into contributing factors for each zone
- **Scenario Simulator** - Test impact of events like festivals, accidents, rain
- **Time-based Trends** - Track emotion changes throughout the day

## 🛠️ Tech Stack

- **Frontend**: HTML5, CSS3, JavaScript (ES6+)
- **Charts**: Chart.js
- **Maps**: map.js
- **Backend API**: Node.js

## 📁 Project Structure

